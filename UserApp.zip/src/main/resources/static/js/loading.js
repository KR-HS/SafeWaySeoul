$(document).ready(function(){
    setTimeout(function() {
        window.location.href = "/user/login";
    }, 5000);
})
