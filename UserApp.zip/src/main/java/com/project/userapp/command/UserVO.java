package com.project.userapp.command;

public class UserVO {
}
